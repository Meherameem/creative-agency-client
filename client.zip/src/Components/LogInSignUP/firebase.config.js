const firebaseConfig = {
    apiKey: "AIzaSyCQtnnivsKlUQfNJvRQg8vz8NgVhpLMx64",
    authDomain: "creative-agency-b222e.firebaseapp.com",
    databaseURL: "https://creative-agency-b222e.firebaseio.com",
    projectId: "creative-agency-b222e",
    storageBucket: "creative-agency-b222e.appspot.com",
    messagingSenderId: "402798405333",
    appId: "1:402798405333:web:e39016d20d6e916ff9a45c"
  };
  export default firebaseConfig;